package com.cognizant.educationportal.model;

import java.sql.Date;
import java.util.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "payment_master")
public class Payment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	int sId;
	@Column(name = "s_balance")
	double sBalance;
	@Column(name = "fee_fine")
	double feeFine;
	@Column(name = "total_fees")
	double totalFees;
	@Column(name = "mode_of_payment")
	String modeOfPayment;
	@Column(name = "last_payment_date")
	Date lastDate;

	/*@Column(name="total_amount")
	double totalAmount;
	
		  
	public double getTotalAmount() {
		return totalAmount;
	}


	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}*/


	public int getsId() {
		return sId;
	}


	public void setsId(int sId) {
		this.sId = sId;
	}


	public double getsBalance() {
		return sBalance;
	}


	public void setsBalance(double sBalance) {
		this.sBalance = sBalance;
	}


	public double getFeeFine() {
		return feeFine;
	}


	public void setFeeFine(double feeFine) {
		this.feeFine = feeFine;
	}


	public double getTotalFees() {
		return totalFees;
	}


	public void setTotalFees(double totalFees) {
		this.totalFees = totalFees;
	}


	public String getModeOfPayment() {
		return modeOfPayment;
	}


	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}


	public Date getLastDate() {
		return lastDate;
	}


	public void setLastDate(Date lastDate) {
		this.lastDate = lastDate;
	}

	@Column(name="stud_first_name" , nullable=false)
	String firstName;
	@Column(name="stud_last_name", nullable=false)
	String lastName;
	@Column(name="stream_name", nullable=false)
	String streamName;
	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getStreamName() {
		return streamName;
	}


	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}


	public Payment() {
		super();
	}

 @Override
   public String toString()
   {
	   return sId+" "+sBalance+" "+feeFine+" "+lastDate+" "+modeOfPayment+" "+totalFees+" "+firstName+" "+lastName+" "+streamName+" ";
   }
}
